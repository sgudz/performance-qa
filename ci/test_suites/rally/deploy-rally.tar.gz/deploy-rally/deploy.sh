#!/bin/bash

mkdir /opt/stack
mkdir -p /var/log/docker-logs/remote
chmod +x ./scripts/*.sh

#run: source envars
source envars

pip2.7 install -r ./requirements.txt

#run dep_sys_req.sh
./scripts/dep_sys_req.sh

PIPFILE=`mktemp`
wget -O $PIPFILE https://bootstrap.pypa.io/get-pip.py
python2.7 $PIPFILE
pip2.7 install -U virtualenv
pip2.7 install -U tox
virtualenv -p python2.7 /opt/stack/.venv

#run: init_cluster_vars.sh
./scripts/init_cluster_vars.sh

/opt/stack/.venv/bin/pip install -U -r requirements.txt
/opt/stack/.venv/bin/pip install -U psycopg2

#run: config_user.sh
./scripts/config_user.sh

cd mos-deployment
./deploy_rally.sh
