
KEYSTONE_NAME_PREFIX = "rally_mox_keystone_"
SERVERS_NAME_PREFIX = "rally_mox_server_"
NETWORK_NAME_PREFIX = "rally_mox_net_"
SUBNETWORK_NAME_PREFIX = "rally_mox_subnet_"
VOLUME_NAME_PREFIX = "rally_mox_volume_"
USER_PASSWORD = "password"
