#!/bin/bash

yum -y reinstall centos-release

yum -y install bc
yum -y install git
yum -y install gcc
yum -y install zlib-devel
yum -y install sqlite-devel
yum -y install readline-devel
yum -y install bzip2-devel
yum -y install libgcrypt-devel
yum -y install openssl-devel
yum -y install libffi-devel
yum -y install libxml2-devel
yum -y install libxslt-devel
yum -y install screen
yum -y install java-1.7.0-openjdk.x86_64
yum -y install postgresql-devel
yum -y install gcc-c++
yum -y install freetype-devel libpng-devel
yum -y install python-devel
