#!/bin/bash

. envars

id -u ${USER_NAME} &>/dev/null || useradd -m ${USER_NAME}
grep nofile /etc/security/limits.conf || echo '* soft nofile 50000' >> /etc/security/limits.conf ; echo '* hard nofile 50000' >> /etc/security/limits.conf
cp -r /root/.ssh ${USER_HOME}
chown -R ${USER_NAME} ${USER_HOME}
chown -R ${USER_NAME} /var/log/job-reports
chown -R ${USER_NAME} ${VIRTUALENV_DIR}

# bashrc
cat > ${USER_HOME}/.bashrc <<EOF
test "\${PS1}" || return
shopt -s histappend
HISTCONTROL=ignoredups:ignorespace
HISTFILESIZE=2000
HISTSIZE=1000
export EDITOR=vi
alias ..=cd\ ..
alias ls=ls\ --color=auto
alias ll=ls\ --color=auto\ -lhap
alias vi=vim\ -XNn
alias d=df\ -hT
alias f=free\ -m
alias g=grep\ -iI
alias gr=grep\ -riI
alias l=less
alias n=netstat\ -lnptu
alias p=ps\ aux
alias u=du\ -sh
echo \${PATH} | grep ":\${HOME}/bin" >/dev/null || export PATH="\${PATH}:\${HOME}/bin"
if test \$(id -u) -eq 0
then
export PS1='\[\033[01;41m\]\u@\h:\[\033[01;44m\] \W \[\033[01;41m\] #\[\033[0m\] '
else
export PS1='\[\033[01;33m\]\u@\h\[\033[01;0m\]:\[\033[01;34m\]\W\[\033[01;0m\]$ '
fi
cd ${DEST}
. ${VIRTUALENV_DIR}/bin/activate
. ${USER_HOME}/openrc
EOF

if [ -n "${USE_PROXY}" ]; then
    echo "export HTTP_PROXY=http://${CONTROLLER_HOST}:8888" >> ${USER_HOME}/.bashrc
    echo "export HTTPS_PROXY=http://${CONTROLLER_HOST}:8888" >> ${USER_HOME}/.bashrc
    echo "export OS_INSECURE=1" >> ${USER_HOME}/.bashrc
fi

chown ${USER_NAME} ${USER_HOME}/.bashrc

# vimrc
cat > ${USER_HOME}/.vimrc <<EOF

set nocompatible
set nobackup
set nowritebackup
set noswapfile
set viminfo=
syntax on
colorscheme slate
set ignorecase
set smartcase
set hlsearch
set smarttab
set expandtab
set tabstop=4
set shiftwidth=4
set softtabstop=4
filetype on
filetype plugin on
EOF
chown ${USER_NAME} ${USER_HOME}/.vimrc

    cat >> ${USER_HOME}/.ssh/config <<EOF
User root
EOF

# openrc
scp ${CONTROLLER_HOST}:/root/openrc /tmp/openrc
cat /tmp/openrc | sed -e "s/.*LC_ALL.*//" > ${USER_HOME}/openrc
echo "export FUEL_RELEASE=${FUEL_RELEASE}" >> ${USER_HOME}/openrc
echo "export OS_AUTH_URL_V3=${OS_AUTH_URL/v2.0/v3}" >> ${USER_HOME}/openrc
echo "export OS_DASHBOARD_URL=${OS_DASHBOARD_URL}" >> ${USER_HOME}/openrc
echo "export OS_EC2_URL=${OS_EC2_URL}" >> ${USER_HOME}/openrc
echo "export CONTROLLER_HOST=${CONTROLLER_HOST}" >> ${USER_HOME}/openrc
echo "export CONTROLLER=${CONTROLLER}" >> ${USER_HOME}/openrc
echo "export COMPUTE=${COMPUTE}" >> ${USER_HOME}/openrc
echo "export OS_ADMIN_USERNAME=${OS_ADMIN_USERNAME}" >> ${USER_HOME}/openrc
echo "export OS_ADMIN_PASSWORD=${OS_ADMIN_PASSWORD}" >> ${USER_HOME}/openrc
echo "export OS_ADMIN_TENANT_NAME=${OS_ADMIN_TENANT_NAME}" >> ${USER_HOME}/openrc

chown -R ${USER_NAME} ${USER_HOME}
chown -R ${USER_NAME} ${DEST}
