#!/bin/bash

CONTROLLER_HOST_ID="`fuel node | grep controller | awk '{print $1}' | head -1`"
CONTROLLER_HOST="node-${CONTROLLER_HOST_ID}"
echo "Controller host: ${CONTROLLER_HOST}"

export FUEL_RELEASE=`fuel --fuel-version 2>&1 | grep -e ^release: | awk '{print $2}'`
ssh root@${CONTROLLER_HOST} "sed -i -r \"s/export OS_AUTH_URL='([htp:/0-9.]+)'$/export OS_AUTH_URL='\1v2.0\/'/\" openrc"
export OS_AUTH_URL=`ssh root@${CONTROLLER_HOST} ". openrc; keystone catalog --service identity | grep  internalURL | awk '{print \\$4}'"`
export OS_AUTH_PUBLIC_URL=`ssh root@${CONTROLLER_HOST} ". openrc; keystone catalog --service identity | grep  publicURL | awk '{print \\$4}'"`
export OS_EC2_URL=`ssh root@${CONTROLLER_HOST} ". openrc; keystone catalog --service ec2 | grep  internalURL | awk '{print \\$4}'"`

OS_ADMIN_USERNAME=`ssh root@${CONTROLLER_HOST} ". openrc; echo \\${OS_USERNAME}"`
OS_ADMIN_PASSWORD=`ssh root@${CONTROLLER_HOST} ". openrc; echo \\${OS_PASSWORD}"`
OS_ADMIN_TENANT_NAME=`ssh root@${CONTROLLER_HOST} ". openrc; echo \\${OS_TENANT_NAME}"`

CONTROLLER_OS=`ssh root@${CONTROLLER_HOST} "cat /etc/*-release" | head -n 1 | awk -F"=" '{print $2}'`
OS_PUBLIC_IP=`echo "${OS_AUTH_PUBLIC_URL}" | grep -Eo "([0-9]{1,3}[\.]){3}[0-9]{1,3}"` || true
if [ -z "${OS_PUBLIC_IP}" ]
then
    OS_PUBLIC_NAME=$(echo $OS_AUTH_PUBLIC_URL | awk -F":" '{print $2}' | sed s/"\/"//g)
    OS_PUBLIC_IP=$(ssh root@${CONTROLLER_HOST} "ping -c1 $OS_PUBLIC_NAME" | head -1 | awk '{print $3}' | sed s/"("// | sed s/")"//)
fi
if [ -z "${OS_PUBLIC_IP}" ]
then
    echo "OS_PUBLIC_IP is empty !"
    exit 1
fi
if [ ${CONTROLLER_OS} = CentOS ]; then
    OS_DASHBOARD_URL=http://${OS_PUBLIC_IP}/dashboard/
else
    OS_DASHBOARD_URL=http://${OS_PUBLIC_IP}/horizon/
fi
export OS_DASHBOARD_URL

echo "Fuel release is ${FUEL_RELEASE}"
echo "OS_AUTH_URL = ${OS_AUTH_URL}"
echo "OS_DASHBOARD_URL = ${OS_DASHBOARD_URL}"
echo "OS_EC2_URL = ${OS_EC2_URL}"
echo "OS_ADMIN_USERNAME = ${OS_ADMIN_USERNAME}"
echo "OS_ADMIN_PASSWORD = ${OS_ADMIN_PASSWORD}"
echo "OS_ADMIN_TENANT_NAME = ${OS_ADMIN_TENANT_NAME}"

CONTROLLER="`fuel node | grep controller | wc -l`"
COMPUTE="`fuel node | grep compute | wc -l`"

if [ -z "${FUEL_IP}" ]; then
    IP_MASK=`ip a show dev eth1 | grep "inet\b" | awk '{print $2}'`
    FUEL_IP=${IP_MASK%/*}
fi
echo "Fuel IP is ${FUEL_IP}"
export FUEL_IP

# fix permissions on remote logs
chmod o+r -R /var/log/remote/
chmod o+r -R /var/log/docker-logs/remote/ || :
